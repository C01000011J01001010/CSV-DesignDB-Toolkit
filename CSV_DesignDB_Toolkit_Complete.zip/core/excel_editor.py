import os
import openpyxl

def get_excel_files(target_dir, recursive, workspace_root=None):
    files = []
    for root, dirs, fnames in os.walk(target_dir):
        dirs[:] = [d for d in dirs if not d.startswith('Disabled')]
        if not recursive: dirs.clear()
        for f in fnames:
            if f.endswith('.xlsx') and not f.startswith('~$'):
                full_path = os.path.join(root, f)
                base_dir = workspace_root if workspace_root else target_dir
                try:
                    rel_path = os.path.relpath(full_path, base_dir)
                except ValueError:
                    rel_path = full_path
                files.append(rel_path)
    return files

def read_headers(filepath):
    try:
        wb = openpyxl.load_workbook(filepath, data_only=True)
        ws = wb.active
        headers = []
        for cell in ws[1]:
            headers.append(str(cell.value) if cell.value is not None else "")
        wb.close()
        return True, headers
    except Exception as e:
        return False, str(e)

def write_headers(filepath, headers):
    try:
        wb = openpyxl.load_workbook(filepath)
        ws = wb.active
        for i, h in enumerate(headers, 1):
            ws.cell(row=1, column=i, value=h)
        wb.save(filepath)
        wb.close()
        return True, "저장 성공"
    except Exception as e:
        return False, str(e)

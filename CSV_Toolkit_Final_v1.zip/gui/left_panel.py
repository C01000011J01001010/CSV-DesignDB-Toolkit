import tkinter as tk
from tkinter import ttk
import os
import threading
from gui.widgets import ScrollableFrame
from core.pk_analyzer import analyze_pk_status
from core.excel_editor import get_excel_files, read_headers, write_headers

class LeftPanel(tk.Frame):
    def __init__(self, parent, app, *args, **kwargs):
        super().__init__(parent, bg="#1E1E1E", *args, **kwargs)
        self.app = app

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)

        self.tab1 = tk.Frame(self.notebook, bg="#1E1E1E")
        self.notebook.add(self.tab1, text="1. 스키마 설정")
        self._build_tab1()

        self.tab2 = tk.Frame(self.notebook, bg="#1E1E1E")
        self.notebook.add(self.tab2, text="2. 제약조건 설정")
        self._build_tab2()
        
        self.tab3 = tk.Frame(self.notebook, bg="#1E1E1E")
        self.notebook.add(self.tab3, text="3. CSV 변환 및 인코딩")
        self._build_tab3()
        
        self.tab4 = tk.Frame(self.notebook, bg="#1E1E1E")
        self.notebook.add(self.tab4, text="4. 후보키 분석")
        self._build_tab4()

        self.tab5 = tk.Frame(self.notebook, bg="#1E1E1E")
        self.notebook.add(self.tab5, text="5. PK 검증 및 추천")
        self._build_tab5()

    # ==========================
    # Tab 1: Schema Setup
    # ==========================
    def _build_tab1(self):
        scroll_frame = ScrollableFrame(self.tab1)
        scroll_frame.pack(fill="both", expand=True)
        self.tab1_inner = scroll_frame.inner_frame

        top_frame = tk.Frame(self.tab1_inner, bg="#1E1E1E")
        top_frame.pack(fill="x", padx=10, pady=(15, 5))
        
        tk.Label(top_frame, text="대상 엑셀 파일 선택:", font=("맑은 고딕", 10), fg="#CCCCCC", bg="#1E1E1E").pack(side="left")
        self.t1_combo_files = ttk.Combobox(top_frame, state="readonly", width=40)
        self.t1_combo_files.pack(side="left", padx=10)
        
        btn_refresh = tk.Button(top_frame, text="새로고침", font=("맑은 고딕", 9), bg="#444444", fg="white", bd=0, command=self._t1_refresh_files)
        btn_refresh.pack(side="left", padx=2)
        btn_load = tk.Button(top_frame, text="헤더 로드", font=("맑은 고딕", 9, "bold"), bg="#007ACC", fg="white", bd=0, command=self._t1_load_headers)
        btn_load.pack(side="left", padx=2)

        self.t1_rows_frame = tk.Frame(self.tab1_inner, bg="#252526", bd=1, relief="solid")
        self.t1_rows_frame.pack(fill="x", padx=10, pady=10)
        
        self.t1_row_widgets = []
        
        btn_frame = tk.Frame(self.tab1_inner, bg="#1E1E1E")
        btn_frame.pack(fill="x", padx=10, pady=5)
        
        btn_add = tk.Button(btn_frame, text="+ 새 컬럼 추가", font=("맑은 고딕", 10), bg="#444444", fg="white", bd=0, command=self._t1_add_row)
        btn_add.pack(side="left")
        
        btn_save = tk.Button(btn_frame, text="✅ 엑셀에 스키마 저장", font=("맑은 고딕", 10, "bold"), bg="#28A745", fg="white", bd=0, command=self._t1_save_headers)
        btn_save.pack(side="right")

    def _t1_refresh_files(self):
        files = get_excel_files(self.app.target_dir, self.app.include_subdirs.get())
        if files:
            self.t1_combo_files['values'] = files
            self.t1_combo_files.current(0)
            self.app.right_panel.log(f"엑셀 파일 {len(files)}개 스캔 완료.")
        else:
            self.t1_combo_files['values'] = []
            self.t1_combo_files.set('')
            self.app.right_panel.log("발견된 엑셀 파일이 없습니다.")

    def _t1_load_headers(self):
        filepath = self.t1_combo_files.get()
        if not filepath: return
        success, data = read_headers(filepath)
        if not success:
            self.app.right_panel.log(f"❌ 헤더 로드 실패: {data}")
            return
            
        for w in self.t1_rows_frame.winfo_children(): w.destroy()
        self.t1_row_widgets.clear()
        
        tk.Label(self.t1_rows_frame, text="컬럼명", width=15, bg="#252526", fg="#00FF66", font=("맑은 고딕", 9, "bold")).grid(row=0, column=0, pady=5)
        tk.Label(self.t1_rows_frame, text="타입 선택", width=15, bg="#252526", fg="#00FF66", font=("맑은 고딕", 9, "bold")).grid(row=0, column=1, pady=5)

        for h in data:
            if not h: continue
            self._t1_create_row(h)
        self.app.right_panel.log(f"▶ {os.path.basename(filepath)} 헤더 로드 완료")

    def _t1_create_row(self, header_str=""):
        row_idx = len(self.t1_row_widgets) + 1
        name = header_str
        ctype = ""
        
        if header_str.startswith('{') and header_str.endswith('}'):
            parts = [p.strip() for p in header_str[1:-1].split('/')]
            name = parts[0]
            if len(parts) > 1: ctype = parts[1]
        
        ent_name = tk.Entry(self.t1_rows_frame, font=("Consolas", 10), bg="#1E1E1E", fg="white", insertbackground="white", width=20)
        ent_name.insert(0, name)
        ent_name.grid(row=row_idx, column=0, padx=5, pady=2)
        
        combo_type = ttk.Combobox(self.t1_rows_frame, state="readonly", width=15, 
                                  values=["int", "int[]", "float", "float[]", "string", "string[]", "bool", "bool[]", "AssetId", "AssetId[]", "ForeignKey", "ForeignKey[]"])
        if ctype: combo_type.set(ctype)
        combo_type.grid(row=row_idx, column=1, padx=5, pady=2)
        
        self.t1_row_widgets.append((ent_name, combo_type))

    def _t1_add_row(self):
        self._t1_create_row()

    def _t1_save_headers(self):
        filepath = self.t1_combo_files.get()
        if not filepath: return
        
        new_headers = []
        for ent_name, combo_type in self.t1_row_widgets:
            name = ent_name.get().strip()
            ctype = combo_type.get().strip()
            if not name: continue
            
            # AssetID, ForeignKey 자동 REF 추가 로직
            if ctype.lower() in ["assetid", "assetid[]", "foreignkey", "foreignkey[]"]:
                new_headers.append(f"{{{name}/{ctype}/REF}}")
            elif ctype:
                new_headers.append(f"{{{name}/{ctype}}}")
            else:
                new_headers.append(f"{{{name}}}")
                
        success, msg = write_headers(filepath, new_headers)
        if success:
            self.app.right_panel.log(f"✅ {os.path.basename(filepath)} 스키마 저장 완료.")
            self._t1_load_headers()
        else:
            self.app.right_panel.log(f"❌ 저장 실패: {msg}")

    # ==========================
    # Tab 2: Constraint Setup
    # ==========================
    def _build_tab2(self):
        scroll_frame = ScrollableFrame(self.tab2)
        scroll_frame.pack(fill="both", expand=True)
        self.tab2_inner = scroll_frame.inner_frame

        top_frame = tk.Frame(self.tab2_inner, bg="#1E1E1E")
        top_frame.pack(fill="x", padx=10, pady=(15, 5))
        
        tk.Label(top_frame, text="대상 엑셀 파일 선택:", font=("맑은 고딕", 10), fg="#CCCCCC", bg="#1E1E1E").pack(side="left")
        self.t2_combo_files = ttk.Combobox(top_frame, state="readonly", width=40)
        self.t2_combo_files.pack(side="left", padx=10)
        
        btn_refresh = tk.Button(top_frame, text="새로고침", font=("맑은 고딕", 9), bg="#444444", fg="white", bd=0, command=self._t2_refresh_files)
        btn_refresh.pack(side="left", padx=2)
        btn_load = tk.Button(top_frame, text="헤더 로드", font=("맑은 고딕", 9, "bold"), bg="#007ACC", fg="white", bd=0, command=self._t2_load_headers)
        btn_load.pack(side="left", padx=2)

        self.t2_rows_frame = tk.Frame(self.tab2_inner, bg="#252526", bd=1, relief="solid")
        self.t2_rows_frame.pack(fill="x", padx=10, pady=10)
        
        self.t2_row_widgets = []
        
        btn_frame = tk.Frame(self.tab2_inner, bg="#1E1E1E")
        btn_frame.pack(fill="x", padx=10, pady=5)
        
        btn_save = tk.Button(btn_frame, text="✅ 엑셀에 제약조건 저장", font=("맑은 고딕", 10, "bold"), bg="#28A745", fg="white", bd=0, command=self._t2_save_headers)
        btn_save.pack(side="right")

    def _t2_refresh_files(self):
        files = get_excel_files(self.app.target_dir, self.app.include_subdirs.get())
        if files:
            self.t2_combo_files['values'] = files
            self.t2_combo_files.current(0)
        else:
            self.t2_combo_files['values'] = []
            self.t2_combo_files.set('')

    def _t2_load_headers(self):
        filepath = self.t2_combo_files.get()
        if not filepath: return
        success, data = read_headers(filepath)
        if not success: return
            
        for w in self.t2_rows_frame.winfo_children(): w.destroy()
        self.t2_row_widgets.clear()
        
        tk.Label(self.t2_rows_frame, text="컬럼 기본정보 (이름/타입)", width=25, bg="#252526", fg="#00FF66", font=("맑은 고딕", 9, "bold")).grid(row=0, column=0, pady=5)
        tk.Label(self.t2_rows_frame, text="제약조건 (PK/UNIQUE/REF/CHECK...)", width=40, bg="#252526", fg="#00FF66", font=("맑은 고딕", 9, "bold")).grid(row=0, column=1, pady=5)

        for h in data:
            if not h: continue
            self._t2_create_row(h)
        self.app.right_panel.log(f"▶ {os.path.basename(filepath)} 제약조건 편집 준비 완료")

    def _t2_create_row(self, header_str=""):
        row_idx = len(self.t2_row_widgets) + 1
        base_info = header_str
        const_info = ""
        
        if header_str.startswith('{') and header_str.endswith('}'):
            parts = [p.strip() for p in header_str[1:-1].split('/')]
            if len(parts) >= 2:
                base_info = f"{parts[0]}/{parts[1]}"
                const_info = "/".join(parts[2:])
            else:
                base_info = parts[0]
        
        lbl_base = tk.Label(self.t2_rows_frame, text=base_info, bg="#252526", fg="#D4D4D4", font=("Consolas", 10), width=25, anchor="w")
        lbl_base.grid(row=row_idx, column=0, padx=5, pady=2)
        
        ent_const = tk.Entry(self.t2_rows_frame, font=("Consolas", 10), bg="#1E1E1E", fg="white", insertbackground="white", width=40)
        ent_const.insert(0, const_info)
        ent_const.grid(row=row_idx, column=1, padx=5, pady=2)
        
        self.t2_row_widgets.append((base_info, ent_const))

    def _t2_save_headers(self):
        filepath = self.t2_combo_files.get()
        if not filepath: return
        
        new_headers = []
        for base_info, ent_const in self.t2_row_widgets:
            const_str = ent_const.get().strip()
            if const_str:
                new_headers.append(f"{{{base_info}/{const_str}}}")
            else:
                new_headers.append(f"{{{base_info}}}")
                
        success, msg = write_headers(filepath, new_headers)
        if success:
            self.app.right_panel.log(f"✅ {os.path.basename(filepath)} 제약조건 저장 완료.")
            self._t2_load_headers()
        else:
            self.app.right_panel.log(f"❌ 저장 실패: {msg}")

    # ==========================
    # Tab 3: CSV Convert
    # ==========================
    def _build_tab3(self):
        scroll_frame = ScrollableFrame(self.tab3)
        scroll_frame.pack(fill="both", expand=True)
        inner = scroll_frame.inner_frame
        
        self.app.btn1 = tk.Button(inner, text="엑셀 전체 일괄 변환 (XLSX ➔ CSV)", font=("맑은 고딕", 11, "bold"), bg="#007ACC", fg="white", bd=0, height=2, command=self.app.run_xlsx_to_csv_all)
        self.app.btn1.pack(fill="x", padx=10, pady=10)
        
        self.app.btn2 = tk.Button(inner, text="인코딩 전체 일괄 변환 (ANSI ➔ UTF-8)", font=("맑은 고딕", 11, "bold"), bg="#28A745", fg="white", bd=0, height=2, command=self.app.run_ansi_to_utf8_all)
        self.app.btn2.pack(fill="x", padx=10, pady=5)
        
        self.app.btn3 = tk.Button(inner, text="백그라운드 자동 변환 감시 모드 시작", font=("맑은 고딕", 11, "bold"), bg="#6C757D", fg="white", bd=0, height=2, command=self.app.toggle_watch_mode)
        self.app.btn3.pack(fill="x", padx=10, pady=5)

    # ==========================
    # Tab 4: Candidate Finder
    # ==========================
    def _build_tab4(self):
        scroll_frame = ScrollableFrame(self.tab4)
        scroll_frame.pack(fill="both", expand=True)
        inner = scroll_frame.inner_frame

        guide_frame = tk.Frame(inner, bg="#252526", bd=1, relief="solid")
        guide_frame.pack(fill="x", padx=10, pady=(15, 10))
        
        guide_text = (
            "📌 [CSV 컬럼 제외(Pass) 가이드 및 타입 정책]\n\n"
            "• 타입 표기: 단일 타입(Type), 배열 표기(Type[]) 지원\n"
            "  (배열 표기 시 자동으로 후보키 분석에서 제외됩니다.)\n"
            "• 스킵(Pass) 키워드 : Ref, FK, FOREIGNKEY, ARR, ARRAY\n"
            "• 제약조건 띄어쓰기: CHECK ( VALUE > 10 ) 처럼 식별 가능하게 공백 필수\n"
            "• 컬럼 데이터 값 자체에 '|' 또는 '_' 문자가 포함되어도 자동 제외됩니다."
        )
        tk.Label(guide_frame, text=guide_text, font=("맑은 고딕", 9), fg="#D4D4D4", bg="#252526", justify="left", anchor="w", padx=10, pady=10).pack(fill="x")

        opt_frame2 = tk.Frame(inner, bg="#1E1E1E")
        opt_frame2.pack(fill="x", padx=10, pady=5)
        tk.Label(opt_frame2, text="최대 후보키 조합 길이 (연산량 조절용):", font=("맑은 고딕", 10), fg="#CCCCCC", bg="#1E1E1E").pack(side="left")
        tk.Spinbox(opt_frame2, from_=1, to=10, textvariable=self.app.max_combo_var, width=5, font=("Consolas", 10)).pack(side="left", padx=10)

        self.app.btn4 = tk.Button(inner, text="현재 경로 CSV 최소 후보키 탐색 (JSON 자동 생성)", font=("맑은 고딕", 11, "bold"), bg="#9C27B0", fg="white", bd=0, height=3, command=self.app.run_candidate_key_finder)
        self.app.btn4.pack(fill="x", padx=10, pady=10)

        self.app.progress_bar = ttk.Progressbar(inner, variable=self.app.progress_var, maximum=100)
        self.app.progress_bar.pack(fill="x", padx=10, pady=(0, 10))
        
    # ==========================
    # Tab 5: PK Analyzer
    # ==========================
    def _build_tab5(self):
        scroll_frame = ScrollableFrame(self.tab5)
        scroll_frame.pack(fill="both", expand=True)
        inner = scroll_frame.inner_frame

        guide_frame = tk.Frame(inner, bg="#252526", bd=1, relief="solid")
        guide_frame.pack(fill="x", padx=10, pady=(15, 10))
        
        guide_text = (
            "📌 [PK(기본키) 검증 프로세스 규칙]\n\n"
            "• PK 가능 타입은 오직 'int'와 'string' 뿐이며, 배열([])은 불가합니다.\n"
            "• 'string' PK인 경우, 데이터 내부에 '_' 기호가 존재하면 반려됩니다.\n"
            "• 설정된 PK 조합이 반드시 '파일명.json'의 후보키 목록에 있어야 합니다.\n"
            "• 분석 대상 JSON 파일이 없다면 최우선 경고(우선 처리) 대상으로 표시됩니다."
        )
        tk.Label(guide_frame, text=guide_text, font=("맑은 고딕", 9), fg="#D4D4D4", bg="#252526", justify="left", anchor="w", padx=10, pady=10).pack(fill="x")

        self.btn5 = tk.Button(inner, text="현재 경로 CSV 상태 점검 및 PK 리스트업", font=("맑은 고딕", 11, "bold"), bg="#E67E22", fg="white", bd=0, height=3, command=self.run_pk_analyzer)
        self.btn5.pack(fill="x", padx=10, pady=10)
        
    def run_pk_analyzer(self):
        def task():
            self.app.set_buttons_state(False)
            self.btn5.config(state=tk.DISABLED)
            self.app.right_panel.log("\n🚀 [작업 시작] 전체 CSV 파일 PK 무결성 및 후보키 매칭 검사")
            
            analyze_pk_status(
                target_dir=self.app.target_dir,
                include_subdirs=self.app.include_subdirs.get(),
                on_log=self.app.right_panel.log
            )
            
            self.app.set_buttons_state(True)
            self.btn5.config(state=tk.NORMAL)
            
        threading.Thread(target=task, daemon=True).start()

import tkinter as tk
from tkinter import ttk
from gui.widgets import ScrollableFrame

class LeftPanel(tk.Frame):
    def __init__(self, parent, app, *args, **kwargs):
        super().__init__(parent, bg="#1E1E1E", *args, **kwargs)
        self.app = app

        # 탭 부분 (탭 헤더는 고정됨)
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)

        # --- 탭 1: 포맷 변환기 ---
        self.tab1 = tk.Frame(self.notebook, bg="#1E1E1E")
        self.notebook.add(self.tab1, text="1. 포맷 & 인코딩 변환")
        self._build_tab1()

        # --- 탭 2: 최소 후보키 탐색 ---
        self.tab2 = tk.Frame(self.notebook, bg="#1E1E1E")
        self.notebook.add(self.tab2, text="2. 최소 후보키 탐색 (CSV)")
        self._build_tab2()

    def _build_tab1(self):
        # 탭 내부에 ScrollableFrame을 넣어 탭 버튼을 제외한 내용물만 스크롤되게 구현
        scroll_frame = ScrollableFrame(self.tab1)
        scroll_frame.pack(fill="both", expand=True)
        inner = scroll_frame.inner_frame

        tk.Checkbutton(inner, text="하위 폴더 포함하여 적용 (재귀적 탐색 및 감시)", variable=self.app.include_subdirs, font=("맑은 고딕", 10),
                       bg="#1E1E1E", fg="#CCCCCC", selectcolor="#2D2D2D", activebackground="#1E1E1E", activeforeground="white", command=self.app.on_option_changed).pack(anchor="w", padx=10, pady=(15, 5))
        
        self.app.btn1 = tk.Button(inner, text="엑셀 전체 일괄 변환 (XLSX ➔ CSV)", font=("맑은 고딕", 11, "bold"), bg="#007ACC", fg="white", bd=0, height=2, command=self.app.run_xlsx_to_csv_all)
        self.app.btn1.pack(fill="x", padx=10, pady=5)
        
        self.app.btn2 = tk.Button(inner, text="인코딩 전체 일괄 변환 (ANSI ➔ UTF-8)", font=("맑은 고딕", 11, "bold"), bg="#28A745", fg="white", bd=0, height=2, command=self.app.run_ansi_to_utf8_all)
        self.app.btn2.pack(fill="x", padx=10, pady=5)
        
        self.app.btn3 = tk.Button(inner, text="백그라운드 자동 변환 감시 모드 시작", font=("맑은 고딕", 11, "bold"), bg="#6C757D", fg="white", bd=0, height=2, command=self.app.toggle_watch_mode)
        self.app.btn3.pack(fill="x", padx=10, pady=5)

    def _build_tab2(self):
        scroll_frame = ScrollableFrame(self.tab2)
        scroll_frame.pack(fill="both", expand=True)
        inner = scroll_frame.inner_frame

        guide_frame = tk.Frame(inner, bg="#252526", bd=1, relief="solid")
        guide_frame.pack(fill="x", padx=10, pady=(15, 10))
        
        guide_text = (
            "📌 [CSV 컬럼 제외(Pass) 작성 가이드]\n\n"
            "• CSV 첫 줄(헤더)을 {컬럼명/키워드} 형태로 작성하면 해당 키워드를 인식하여 제외합니다.\n"
            "• 스킵(Pass) 키워드 : Ref, FK, FOREIGNKEY, ARR, ARRAY (대소문자 구별 없음)\n"
            "  (작성 예시: {유저ID/FK} ➔ '유저ID' 컬럼은 탐색에서 제외됨)\n"
            "• 컬럼 데이터 값 자체에 '|' 또는 '_' 문자가 포함되어 있어도 자동으로 제외됩니다."
        )
        tk.Label(guide_frame, text=guide_text, font=("맑은 고딕", 9), fg="#D4D4D4", bg="#252526", justify="left", anchor="w", padx=10, pady=10).pack(fill="x")

        opt_frame2 = tk.Frame(inner, bg="#1E1E1E")
        opt_frame2.pack(fill="x", padx=10, pady=5)
        tk.Label(opt_frame2, text="최대 후보키 조합 길이 (연산량 조절용):", font=("맑은 고딕", 10), fg="#CCCCCC", bg="#1E1E1E").pack(side="left")
        tk.Spinbox(opt_frame2, from_=1, to=10, textvariable=self.app.max_combo_var, width=5, font=("Consolas", 10)).pack(side="left", padx=10)

        self.app.btn4 = tk.Button(inner, text="현재 경로 CSV 최소 후보키 탐색", font=("맑은 고딕", 11, "bold"), bg="#9C27B0", fg="white", bd=0, height=3, command=self.app.run_candidate_key_finder)
        self.app.btn4.pack(fill="x", padx=10, pady=10)

        self.app.progress_bar = ttk.Progressbar(inner, variable=self.app.progress_var, maximum=100)
        self.app.progress_bar.pack(fill="x", padx=10, pady=(0, 10))
